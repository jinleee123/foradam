package com.example.assignmenttest.recipe;

import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.assignmenttest.R;
import com.example.assignmenttest.mealAPI.AnalyzedInstruction;
import com.example.assignmenttest.mealAPI.ExtendedIngredient;
import com.example.assignmenttest.mealAPI.Step;
import com.example.assignmenttest.mealAPI.WinePairing;
import com.example.assignmenttest.recipe.Recipe;
import com.squareup.picasso.Picasso;

import java.util.List;

public class RecipeDetailFragment extends Fragment {
    public static final String ARG_ITEM_ID = "itemId";
    public static final String TAG = "RecipeDetailFragment";
    private Recipe mRecipe;
    private List<ExtendedIngredient> ingredients;
    private String ingredientList = "";
    private List<AnalyzedInstruction> instructions;
    private String instructionList ="", cuisineString = "";
    private List<Step> steps;
    private WinePairing winePairing;
    private ImageView rImage;
    private View rootView;

    public RecipeDetailFragment() {
    }
    public static RecipeDetailFragment newInstance(Recipe recipe) {
        Bundle args = new Bundle();
        args.putSerializable("recipe", recipe);
        RecipeDetailFragment fragment = new RecipeDetailFragment();
        fragment.setArguments(args);
        return fragment;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_detailrecipe, container, false);
        return rootView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mRecipe = (Recipe) getArguments().getSerializable("recipe");
        setObject(mRecipe);
        updateUi();
    }

    private void updateUi() {


        if (mRecipe != null) {
            System.out.println(mRecipe.getTitle());
            System.out.println("successfully passed object through");
            StringBuffer ingredientsStringBuffer = new StringBuffer();
            for (ExtendedIngredient ingredient : ingredients) {
                String str = ingredient.getName();
                String cap = str.substring(0, 1).toUpperCase() + str.substring(1);
                ingredientList = (ingredientList +
                        "• " + cap + System.getProperty("line.separator"));
            }
            System.out.println(ingredientList);
            for (AnalyzedInstruction instruction : instructions) {
                steps = instruction.getSteps();
                System.out.println("new instruction");
                for (Step step : steps) {
                    instructionList = (instructionList + step.getNumber() + ". " + step.getStep() + System.getProperty("line.separator")+ System.getProperty("line.separator"));
                }
            }
            System.out.println(instructionList);
            System.out.println("instruction list printed");
            System.out.println("Wine pairing: " + winePairing.getPairingText());

            if(!(mRecipe.getCuisines()==null)){
                for(String string: mRecipe.getCuisines()){
                    cuisineString=cuisineString+string +", ";
                }if(cuisineString.length()>2){
                cuisineString=cuisineString.substring(0, cuisineString.length()-2);
            }}else{cuisineString="World";
            }

            this.rImage = rootView.findViewById(R.id.ivRecipe);
            ((TextView) rootView.findViewById(R.id.tvName)).setText(mRecipe.getTitle());
            ((TextView) rootView.findViewById(R.id.tv_winePairing)).setText(winePairing.getPairingText());
            ((TextView) rootView.findViewById(R.id.tvCuisine)).setText(cuisineString);
            ((TextView) rootView.findViewById(R.id.tv_ingredients)).setText(ingredientList);
            ((TextView) rootView.findViewById(R.id.tvHealthscore)).setText(mRecipe.getHealthScore().toString());
            ((TextView) rootView.findViewById(R.id.tvInstructions)).setText(instructionList);

            String imageStr = "https://spoonacular.com/recipeImages/" + mRecipe.getId() + "-312x231." + mRecipe.getImageType();
            Picasso.with(rImage.getContext()).load(Uri.parse(imageStr)).into(rImage);
        }
    }






    public void setObject(Recipe recipe) {
        this.mRecipe = recipe;
        this.ingredients = recipe.getExtendedIngredients();
        this.instructions = recipe.getAnalyzedInstructions();
        this.winePairing = recipe.getWinePairing();
        System.out.println("Object set");
    }


}
