package com.example.assignmenttest.profile;

import com.example.assignmenttest.Achievement;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Profile {
    private String firstName;
    private String lastName;
    private String username;
    private String password;
    private Calendar dob = Calendar.getInstance();
    private ArrayList<String> foodInterests = new ArrayList<>();
    private boolean vegetarian;
    private boolean vegan;
    private boolean glutenFree;
    private boolean dairyFree;
    private int recipesCompleted;
    private int videoTutorialsCompleted;
    private int quizAverage;
    private int xp = 0;
    private ArrayList<Achievement> achievementList;
    private String level = "Salad";


    // initialize user, add 1 to static count and
    // output String indicating that constructor was called
    public Profile(String first, String last )
    {
        this.firstName = first;
        this.lastName = last;
    }
    public Profile(String first, String last, String name, String pass)
    {
        this.firstName = first;
        this.lastName = last;
        this.username = name;
        this.password = pass;

    }
    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }
    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }
    public void setUserName(String name)
    {
        this.username = name;
    }
    public void setPassword(String password)
    {
        this.password = password;
    }
    public void setDOB(int year, int month, int day)
    {
        this.dob.set(year, month, day);
    }
    public String getUserName()
    {
        return username;
    }
    public String getPassword()
    {
        return password;
    }
    public String getFirstName()
    {
        return firstName;
    }
    public String getLastName()
    {
        return lastName;
    }
    public Calendar getDOB()
    {
        return dob;
    }
    public Boolean getVegetarian() {
        return vegetarian;
    }
    public void setLevel(String level)
    {
        this.level = level;
    }
    public String getLevel()
    {
        return level;
    }

    public void setVegetarian(Boolean vegetarian) {
        this.vegetarian = vegetarian;
    }

    public Boolean getVegan() {
        return vegan;
    }

    public void setVegan(Boolean vegan) {
        this.vegan = vegan;
    }

    public Boolean getGlutenFree() {
        return glutenFree;
    }

    public void setGlutenFree(Boolean glutenFree) {
        this.glutenFree = glutenFree;
    }

    public Boolean getDairyFree() {
        return dairyFree;
    }

    public void setDairyFree(Boolean dairyFree) {
        this.dairyFree = dairyFree;
    }

    public ArrayList<String> getFoodInterests() {
        return foodInterests;
    }

    public void setFoodInterests(ArrayList<String> foodInterests) {
        this.foodInterests = foodInterests;
    }
    public ArrayList<Achievement> getAchievementList() {
        return achievementList;
    }

    public void setAchievementLists(ArrayList<Achievement> achievements) {
        this.achievementList = achievements;
    }
    public int getRecipesCompleted(){return recipesCompleted;
    }
    public int getVideoTutorialsCompleted(){return videoTutorialsCompleted;
    }
    public int getQuizAverage(){return quizAverage;
    }
    public int getXP(){return xp;
    }
    public void setRecipesCompleted(int rCompleted){this.recipesCompleted = rCompleted;}
    public void setVideoTutorialsCompleted(int viCompleted){this.videoTutorialsCompleted = viCompleted;}
    public void setQuizAverage(int qAverage){this.quizAverage = qAverage;}
    public void setXP(int xp){this.xp = xp;}


}
