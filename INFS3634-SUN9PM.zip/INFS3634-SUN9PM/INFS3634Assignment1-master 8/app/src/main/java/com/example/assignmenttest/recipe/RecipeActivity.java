package com.example.assignmenttest.recipe;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;

import com.example.assignmenttest.R;
import com.example.assignmenttest.Tutorial.TutorialActivity;
import com.example.assignmenttest.profile.ProfileActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.Response;

public class RecipeActivity extends AppCompatActivity {
    public static final String TAG = "RecipeActivity";
    private RecipeAdapter mAdapter;
    private boolean mTwoPane;
    RecyclerView mRecyclerView;
    private ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe);
        dialog = new ProgressDialog(this);
        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.nav_view);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.nav_home:
                        launchTutorialActivity();
                        return true;
                    case R.id.nav_recipe:
                        launchRecipeActivity();
                        return true;
                    case R.id.nav_profile:
                        launchProfileActivity();
                        return true;
                    default: return true;
                }
            }
        });
        if (findViewById(R.id.detailContainer) != null) {
            mTwoPane = true;
        }

        mRecyclerView = findViewById(R.id.rvList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(mLayoutManager);

        mAdapter = new RecipeAdapter(this, new ArrayList<Recipe>(), mTwoPane);
        mRecyclerView.setAdapter(mAdapter);
        new GetRecipeTask().execute();
        dialog.show();
    }

    private class GetRecipeTask extends AsyncTask<Void, Void, List<Recipe>> {
        @Override
        protected List<Recipe> doInBackground(Void... voids) {
            try {
                Log.d(TAG, "doInBackground: SUCESS");

                Retrofit retrofit = new Retrofit.Builder().baseUrl("https://api.spoonacular.com").addConverterFactory(GsonConverterFactory.create()).build();
                RecipeService2 service = retrofit.create(RecipeService2.class);
                Call<Meal2> recipeCall = service.getRecipes();

                Response<Meal2> response = recipeCall.execute();
                List<Recipe> recipes = response.body().getRecipes();
                return recipes;

            } catch (IOException e){
                Log.d(TAG, "onFailure: FAILURE");
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(List<Recipe> recipes) {
            dialog.dismiss();
            mAdapter.setRecipes(recipes);
        }
    }


    public void launchRecipeActivity() {
        Intent intent = new Intent(this, RecipeActivity.class);
        startActivity(intent);
    }
    public void launchProfileActivity() {
        Intent intent = new Intent(this, ProfileActivity.class);
        startActivity(intent);
    }
    public void launchTutorialActivity() {
        Intent intent = new Intent(this, TutorialActivity.class);
        startActivity(intent);
    }

}