package com.example.assignmenttest.profile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;

import com.example.assignmenttest.R;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.util.ArrayList;
import java.util.List;

public class FoodInterestActivity extends AppCompatActivity {
    private Button closeButton, saveButton;
    protected String foodInterests;
    protected ChipGroup foodInterestChips;
    protected List<Integer> foodInterestChipList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_interest);

        foodInterestChips = findViewById(R.id.fiChipGroup);
        for (int i = 0; i < foodInterestChips.getChildCount(); i++) {
            View child = foodInterestChips.getChildAt(i);
            if (child instanceof Chip) {
                child.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ((Chip) child).setChecked(true);
                        ((Chip) child).setCloseIconVisible(true);
                    }
                });
                ((Chip) child).setOnCloseIconClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ((Chip) child).setChecked(false);
                    }
                });

                }
            }
        closeButton = findViewById(R.id.closeButton);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchProfileActivity();
            }
        });
        saveButton = findViewById(R.id.saveButton);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ProfileActivity.foodIntString="";
                ProfileActivity.foodIntList.clear();
                foodInterestChipList = getCheckedChipIds();
                for (Integer integer : foodInterestChipList) {
                    Chip chip = foodInterestChips.findViewById(integer);
                    ProfileActivity.addFoodInterest(chip.getText().toString());
                }
                launchProfileActivity();
            }
        });

    }
    private void launchProfileActivity() {
        Intent intent = new Intent(this, ProfileActivity.class);
        startActivity(intent);
    }
    public List<Integer> getCheckedChipIds() {
        ArrayList<Integer> checkedIds = new ArrayList<>();
        for (int i = 0; i < foodInterestChips.getChildCount(); i++) {
            View child = foodInterestChips.getChildAt(i);
            if (child instanceof Chip) {
                if (((Chip) child).isChecked()) {
                    checkedIds.add(child.getId());
                }
            }
        }

        return checkedIds;
    }
}
