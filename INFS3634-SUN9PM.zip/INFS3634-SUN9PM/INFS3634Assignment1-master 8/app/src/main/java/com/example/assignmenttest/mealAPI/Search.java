package com.example.assignmenttest.mealAPI;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Search {

    @SerializedName("results")
    @Expose
    private List<Result> results = null;
    @SerializedName("baseUri")
    @Expose
    private String baseUri;
    @SerializedName("offset")
    @Expose
    private Double offset;
    @SerializedName("number")
    @Expose
    private Double number;
    @SerializedName("totalResults")
    @Expose
    private Double totalResults;
    @SerializedName("processingTimeMs")
    @Expose
    private Double processingTimeMs;
    @SerializedName("expires")
    @Expose
    private Double expires;
    @SerializedName("isStale")
    @Expose
    private Boolean isStale;

    /**
     * No args constructor for use in serialization
     *
     */
    public Search() {
    }

    /**
     *
     * @param number
     * @param totalResults
     * @param expires
     * @param offset
     * @param processingTimeMs
     * @param baseUri
     * @param isStale
     * @param results
     */
    public Search(List<Result> results, String baseUri, Double offset, Double number, Double totalResults, Double processingTimeMs, Double expires, Boolean isStale) {
        super();
        this.results = results;
        this.baseUri = baseUri;
        this.offset = offset;
        this.number = number;
        this.totalResults = totalResults;
        this.processingTimeMs = processingTimeMs;
        this.expires = expires;
        this.isStale = isStale;
    }

    public List<Result> getResults() {
        return results;
    }

    public void setResults(List<Result> results) {
        this.results = results;
    }

    public String getBaseUri() {
        return baseUri;
    }

    public void setBaseUri(String baseUri) {
        this.baseUri = baseUri;
    }

    public Double getOffset() {
        return offset;
    }

    public void setOffset(Double offset) {
        this.offset = offset;
    }

    public Double getNumber() {
        return number;
    }

    public void setNumber(Double number) {
        this.number = number;
    }

    public Double getTotalResults() {
        return totalResults;
    }

    public void setTotalResults(Double totalResults) {
        this.totalResults = totalResults;
    }

    public Double getProcessingTimeMs() {
        return processingTimeMs;
    }

    public void setProcessingTimeMs(Double processingTimeMs) {
        this.processingTimeMs = processingTimeMs;
    }

    public Double getExpires() {
        return expires;
    }

    public void setExpires(Double expires) {
        this.expires = expires;
    }

    public Boolean getIsStale() {
        return isStale;
    }

    public void setIsStale(Boolean isStale) {
        this.isStale = isStale;
    }

}

