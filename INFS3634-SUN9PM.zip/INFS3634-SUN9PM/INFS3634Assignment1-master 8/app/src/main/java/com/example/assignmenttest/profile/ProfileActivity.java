package com.example.assignmenttest.profile;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.assignmenttest.Achievement;
import com.example.assignmenttest.Quiz.QuizStartingScreenActivity;
import com.example.assignmenttest.R;
import com.example.assignmenttest.Tutorial.TutorialActivity;
import com.example.assignmenttest.profile.FoodInterestActivity;
import com.example.assignmenttest.profile.Profile;
import com.example.assignmenttest.recipe.RecipeActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Calendar;

public class ProfileActivity extends AppCompatActivity {
    private ImageView pImage;
    private TextView fName, lName, userName,dob, foodInterests, aList;
    protected static ArrayList<String> foodIntList = new ArrayList<>();
    protected static String foodIntString = "";
    private Button editProfileButton, addFIButton;
    public static Profile profile;
    private ArrayList<Achievement> achievements;
    private String achievementList = "";
    private String DOB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        if(profile ==null) {
            profile = new Profile("Corona", "Virus", "corona1", "123");
        }
        System.out.println("Created profile");


        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.nav_view);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.nav_home:
                        launchTutorialActivity();
                        return true;
                    case R.id.nav_recipe:
                        launchRecipeActivity();
                        return true;
                    case R.id.nav_profile:
                        launchProfileActivity();
                        return true;
                    default: return true;
                }
            }
        });

        profile.setFoodInterests(foodIntList);
        for(String string:foodIntList){
            foodIntString = (foodIntString + string+", ");
            }if(foodIntString.length()>2){
            foodIntString=foodIntString.substring(0, foodIntString.length()-2);
        }
        System.out.println("Set food interests");


        pImage = findViewById(R.id.pIV);
        System.out.println("Set image");
        fName = findViewById(R.id.fNameValue);
        lName = findViewById(R.id.lNameValue);
        userName = findViewById(R.id.uNameValue2);
        foodInterests = findViewById(R.id.foodInterestsValue);
        dob = findViewById(R.id.dobValue);
        addFIButton = findViewById(R.id.addFIButton);
        editProfileButton = findViewById(R.id.editButton2);
        editProfileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchEditProfileActivity();
            }
        });
        System.out.println("Set views");
        pImage.setImageResource(R.drawable.jamieoliver);

        DOB=profile.getDOB().get(Calendar.DAY_OF_MONTH)+"/"+profile.getDOB().get(Calendar.MONTH)+"/"+profile.getDOB().get(Calendar.YEAR);
        dob.setText(DOB);
        System.out.println("Set DOB");
        fName.setText(profile.getFirstName());
        System.out.println("Set first name");
        lName.setText(profile.getLastName());
        System.out.println("Set last name");
        System.out.println(profile.getUserName());
        userName.setText(profile.getUserName());
        System.out.println("Set names");
        if(foodIntList.isEmpty()){
            foodInterests.setVisibility(View.GONE);
            addFIButton.setVisibility(View.VISIBLE);
            addFIButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    launchFoodInterestActivity();
                }
            });
        }
        else{
            foodInterests.setVisibility(View.VISIBLE);
            addFIButton.setVisibility(View.GONE);
            foodInterests.setText(foodIntString);
        }
        System.out.println("Set food interests");

        aList= findViewById(R.id.aListTV);

        switch (profile.getXP()) {
            case 100:
                achievements.add(Achievement.getAchievement().get(0));
                break;
            case 200:
                achievements.add(Achievement.getAchievement().get(1));
                break;
            case 300:
                achievements.add(Achievement.getAchievement().get(2));
                break;
            case 400:
                achievements.add(Achievement.getAchievement().get(3));
                break;
        }
        if (achievements==null) {
            aList.setText("Start practicing recipes and completing quizzes to gain XP!");
        } else {
            for (Achievement achievement : achievements) {
                achievementList = (achievementList + "• " + achievement.getName() + ": " + achievement.getDesciprtion() + System.getProperty("line.separator"));
            }
            aList.setText(achievementList);

        }


    }

    public void launchRecipeActivity() {
        Intent intent = new Intent(this, RecipeActivity.class);
        startActivity(intent);
    }
    public void launchProfileActivity() {
        Intent intent = new Intent(this, ProfileActivity.class);
        startActivity(intent);
    }
    public void launchTutorialActivity() {
        Intent intent = new Intent(this, TutorialActivity.class);
        startActivity(intent);
    }


    private void launchFoodInterestActivity() {
        Intent intent = new Intent(this, FoodInterestActivity.class);
        startActivity(intent);
    }
    private void launchEditProfileActivity() {
        Intent intent = new Intent(this, editProfileActivity.class);
        startActivity(intent);
    }
    protected static void addFoodInterest(String interest){
        foodIntList.add(interest);
    }
    public static void increaseXP(){
        if(profile==null){ profile = new Profile("Corona", "Virus", "corona1", "123");
        }
        profile.setXP(profile.getXP()+100);
    }
    public static int retrieveXP(){
        if(profile==null){ profile = new Profile("Corona", "Virus", "corona1", "123");
        }
        return profile.getXP();
    }
    public static void setLevel(String level){
        if(profile==null){ profile = new Profile("Corona", "Virus", "corona1", "123");
        }
        profile.setLevel(level);
    }
    public static String getLevel(){
        if(profile==null){ profile = new Profile("Corona", "Virus", "corona1", "123");
        }
        return profile.getLevel();
    }


}
