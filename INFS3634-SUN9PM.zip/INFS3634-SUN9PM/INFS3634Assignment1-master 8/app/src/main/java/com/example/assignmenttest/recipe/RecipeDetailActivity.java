package com.example.assignmenttest.recipe;

import android.os.Bundle;
import android.view.MenuItem;

import com.example.assignmenttest.R;
import com.google.gson.Gson;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class RecipeDetailActivity extends AppCompatActivity {
    private Recipe recipe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Detail");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        if (savedInstanceState == null) {
            Gson gson = new Gson();
            recipe = gson.fromJson(getIntent().getStringExtra("myjson"), Recipe.class);
            RecipeDetailFragment fragment =  RecipeDetailFragment.newInstance(recipe);
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.detailContainerScrolls, fragment)
                    .commit();
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId()==android.R.id.home){
            finish();
        }

        return super.onOptionsItemSelected(item);
    }
}
