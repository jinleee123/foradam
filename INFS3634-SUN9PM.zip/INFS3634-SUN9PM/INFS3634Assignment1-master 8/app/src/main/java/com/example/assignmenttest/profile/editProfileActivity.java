package com.example.assignmenttest.profile;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.TextView;

import com.example.assignmenttest.R;

import java.util.Calendar;

import static com.example.assignmenttest.profile.ProfileActivity.profile;

public class editProfileActivity extends AppCompatActivity {
    private EditText fnameEdit, lnameEdit, usernameEdit, date_field;
    private DatePicker dobEDIT;
    private CheckBox vegetarianEdit, veganEdit, dairyfreeEdit, glutenfreeEdit;
    private TextView foodIntValue;
    private Button saveButton;
    private ImageButton addFIbtn;
    private String DOB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        addFIbtn = findViewById(R.id.addFI);
        addFIbtn.setImageResource(R.drawable.ic_add_black_24dp);
        addFIbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchFoodInterestActivity();
            }
        });
        fnameEdit = findViewById(R.id.fNameValue);
        fnameEdit.setText(profile.getFirstName());
        lnameEdit = findViewById(R.id.lnameValue);
        lnameEdit.setText(profile.getLastName());
        usernameEdit = findViewById(R.id.uNameValue);
        usernameEdit.setText(profile.getUserName());
        date_field = (EditText)findViewById(R.id.dobValue);
        DOB=profile.getDOB().get(Calendar.DAY_OF_MONTH)+"/"+profile.getDOB().get(Calendar.MONTH)+"/"+profile.getDOB().get(Calendar.YEAR);
        date_field.setText(DOB);
        date_field.setFocusable(false); // disable editing of this field
        date_field.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                chooseDate();
            }
        });

        foodIntValue = findViewById(R.id.fiValue);
        if(ProfileActivity.foodIntList.isEmpty()){
            foodIntValue.setVisibility(View.GONE);
            addFIbtn.setVisibility(View.VISIBLE);
            addFIbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    launchFoodInterestActivity();
                }
            });
        }
        else{
            foodIntValue.setVisibility(View.VISIBLE);
            foodIntValue.setText(ProfileActivity.foodIntString);
        }

        //dobEDIT = findViewById(R.id.dobValue);

        saveButton = findViewById(R.id.saveButton);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                profile.setLastName(lnameEdit.getText().toString());
                profile.setFirstName(fnameEdit.getText().toString());
                profile.setUserName(usernameEdit.getText().toString());
                launchProfileActivity();
            }
            });

    }
    private void launchFoodInterestActivity() {
        Intent intent = new Intent(this, FoodInterestActivity.class);
        startActivity(intent);
    }
    private void launchProfileActivity() {
        Intent intent = new Intent(this, ProfileActivity.class);
        startActivity(intent);
    }

    private void chooseDate() {
        final Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog datePicker =
                new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(final DatePicker view, final int year, final int month,
                                          final int dayOfMonth) {

                        profile.setDOB(year, month, dayOfMonth);
                        DOB=profile.getDOB().get(Calendar.DAY_OF_MONTH)+"/"+profile.getDOB().get(Calendar.MONTH)+"/"+profile.getDOB().get(Calendar.YEAR);
                        date_field.setText(DOB);
                    }
                }, year, month, day); // set date picker to current date

        datePicker.show();

        datePicker.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(final DialogInterface dialog) {
                dialog.dismiss();
            }
        });
    }
}
