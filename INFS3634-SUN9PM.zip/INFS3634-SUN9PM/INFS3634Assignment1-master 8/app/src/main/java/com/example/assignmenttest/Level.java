package com.example.assignmenttest;

import com.example.assignmenttest.recipe.Recipe;

import java.util.ArrayList;
import java.util.List;

public class Level {
    private int number;
    private String status;
    private List<Recipe> recipeList;
    private String theme;
    private int lImage;

    public int getnumber(){return number;
    }

    public void setNumber(int number){this.number = number;}

    public List<Recipe> getRecipeList() {
        return recipeList;
    }

    public void setRecipeList(List<Recipe> recipes) {
        this.recipeList = recipes;
    }

    public String getTheme(){return theme;
    }
    public void setStatus(String levelTheme){this.status = levelTheme;}
    public String getStatus(){return status;
    }
    public void setTheme(String levelTheme){this.theme = levelTheme;}

    public Level(int number, ArrayList<Recipe> recipeList, String theme){
        this.number=number;
        this.recipeList=recipeList;
    }
    public Level(int number, String theme, int image){
        this.number=number;
        this.theme=theme;
        this.lImage=image;
    }

    public Level(int number, String inProgress, String theme, int image){
        this.number=number;
        this.status=inProgress;
        this.theme = theme;
        this.lImage=image;
    }
    public int getImage() {
        return lImage;
    }

    public void setImage(int rImage) {
        this.lImage = rImage;
    }

    public static ArrayList<Level> getLevel() {
        ArrayList<Level> levels = new ArrayList<>();
        levels.add(new Level(1, "In Progress", "Salad", R.drawable.salad));
        levels.add(new Level(2, "Omelette", R.drawable.omelette));
        levels.add(new Level(3,  "Pasta", R.drawable.pasta));
        levels.add(new Level(4, "Soup", R.drawable.soup));
        return levels;
    }

}

