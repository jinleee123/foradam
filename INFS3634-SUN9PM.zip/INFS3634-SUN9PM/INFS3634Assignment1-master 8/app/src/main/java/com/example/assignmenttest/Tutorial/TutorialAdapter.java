package com.example.assignmenttest.Tutorial;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.assignmenttest.Level;
import com.example.assignmenttest.R;
import com.example.assignmenttest.profile.ProfileActivity;
import com.example.assignmenttest.recipe.Recipe;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import static com.example.assignmenttest.Tutorial.TutorialDetailActivity.*;

public class TutorialAdapter extends RecyclerView.Adapter<TutorialAdapter.TutorialViewHolder> implements Serializable {
    private TutorialActivity mTutorialActivity;
    public ArrayList<Level> mLevels;
    public static final String TAG = "TutorialAdapter";
    private static final String SALAD_STATE = "saladState";
    private static final String OMELETTE_STATE = "omeletteState";
    private static final String PASTA_STATE = "pastaState";
    private static final String SOUP_STATE = "soupState";
    public static final String SHARED_PREFS = "sharedPrefs";
    private String saladStatus, omeletteStatus, pastaStatus, soupStatus;

    private View.OnClickListener mOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Level level = (Level) v.getTag();
            List<Recipe> lRecipes = level.getRecipeList();
                Context context = v.getContext();
                Intent intent = new Intent(context, TutorialDetailActivity.class);
                intent.putExtra("Level", level.getnumber()-1);
            ProfileActivity.setLevel(level.getTheme());
                context.startActivity(intent);


        }
    };


    public TutorialAdapter(TutorialActivity parent, ArrayList<Level> levels) {
        mTutorialActivity = parent;
        mLevels = levels;
    }

    public static class TutorialViewHolder extends RecyclerView.ViewHolder{
        public TextView title, recipes, status;
        public ImageView lImage;

        public TutorialViewHolder(View v) {
            super(v);
            title = v.findViewById(R.id.tvTitle);
            recipes = v.findViewById(R.id.tvNoRecipes);
            status = v.findViewById(R.id.tvStatus);
            lImage = v.findViewById(R.id.levelImage);
        }
    }
    @Override
    public TutorialAdapter.TutorialViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.tutorial_list_row, parent, false);
        return new TutorialViewHolder(v);
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(TutorialViewHolder holder, int position) {
        Level level = mLevels.get(position);
        holder.title.setText("Level " + level.getnumber());
        holder.recipes.setText(level.getTheme());
        holder.lImage.setImageResource(level.getImage());
        loadLevelStatus(level);
        holder.status.setText(level.getStatus());
        holder.itemView.setTag(level);
        holder.itemView.setOnClickListener(mOnClickListener);
    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return mLevels.size();
    }

    public void setLevels(ArrayList<Level> levels) {
        System.out.println("Reached setLevels");
        mLevels.clear();
        mLevels.addAll(levels);
        notifyDataSetChanged();
    }
    private void loadLevelStatus(Level level) {
        SharedPreferences prefs = mTutorialActivity.getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        switch(level.getTheme()){
            case "Salad":
                level.setStatus(prefs.getString(SALAD_STATE, "In Progress"));
                break;
            case "Omelette":
                level.setStatus(prefs.getString(SALAD_STATE, ""));
                break;
            case "Pasta":
                level.setStatus(prefs.getString(SALAD_STATE, ""));
                break;
            case "Soup":
                level.setStatus(prefs.getString(SALAD_STATE, ""));
                break;
            }
        }
    }


