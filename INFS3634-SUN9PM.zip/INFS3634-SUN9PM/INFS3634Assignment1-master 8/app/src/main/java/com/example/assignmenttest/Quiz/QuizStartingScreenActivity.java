package com.example.assignmenttest.Quiz;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;


import com.example.assignmenttest.R;
import com.example.assignmenttest.Tutorial.TutorialActivity;
import com.example.assignmenttest.profile.ProfileActivity;
import com.example.assignmenttest.recipe.RecipeActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.List;

import static android.content.Context.MODE_PRIVATE;

public class QuizStartingScreenActivity extends AppCompatActivity {
    private static final int REQUEST_CODE_QUIZ = 1;
    public static final String EXTRA_THEME_ID = "extraThemeID";
    public static final String EXTRA_THEME_NAME = "extraThemeName";
    public static final String SHARED_PREFS = "sharedPrefs";
    public static final String KEY_HIGHSCORE = "keyHighscore";
    private TextView textViewHighscore, themeTV;
    private Spinner spinnerTheme;
    private int highscore;
    private int quizThemeID;
    private String quizThemeString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_starting_screen);
        quizThemeString = getIntent().getStringExtra("ThemeName");
        quizThemeID = getIntent().getIntExtra("ThemeID", 1);
        System.out.println(quizThemeString + ": " + quizThemeID);

        textViewHighscore = findViewById(R.id.text_view_highscore);
        themeTV = findViewById(R.id.themeTV);
        themeTV.setText(quizThemeString);

        loadHighscore();

        Button buttonStartQuiz = findViewById(R.id.button_start_quiz);
        buttonStartQuiz.setOnClickListener(v -> startQuiz(quizThemeID, quizThemeString));

        Button instructions = findViewById(R.id.instructions);

        instructions.setOnClickListener(v -> {
            Intent i = new Intent(getApplicationContext(), PopupActivity.class);
            startActivity(i);
        });
        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.nav_view);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.nav_home:
                        launchTutorialActivity();
                        return true;
                    case R.id.nav_recipe:
                        launchRecipeActivity();
                        return true;
                    case R.id.nav_profile:
                        launchProfileActivity();
                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    private void startQuiz(int quizThemeID, String quizThemeString) {


        Intent intent = new Intent(QuizStartingScreenActivity.this, QuizActivity.class);
        intent.putExtra(EXTRA_THEME_ID, quizThemeID);
        intent.putExtra(EXTRA_THEME_NAME, quizThemeString);
        startActivityForResult(intent, REQUEST_CODE_QUIZ);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_QUIZ) {
            if (resultCode == RESULT_OK) {
                int score = data.getIntExtra(QuizActivity.EXTRA_SCORE, 0);
                if (score > highscore) {
                    updateHighscore(score);
                }
            }
        }
    }


    private void loadHighscore() {
        SharedPreferences prefs = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        highscore = prefs.getInt(KEY_HIGHSCORE, 0);
        textViewHighscore.setText(getResources().getString(R.string.high_score) + highscore);
    }

    private void updateHighscore(int highscoreNew) {
        highscore = highscoreNew;
        textViewHighscore.setText(getResources().getString(R.string.high_score) + highscore);

        SharedPreferences prefs = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(KEY_HIGHSCORE, highscore);
        editor.apply();
    }

    public void launchRecipeActivity() {
        Intent intent = new Intent(this, RecipeActivity.class);
        startActivity(intent);
    }

    public void launchProfileActivity() {
        Intent intent = new Intent(this, ProfileActivity.class);
        startActivity(intent);
    }

    public void launchTutorialActivity() {
        Intent intent = new Intent(this, TutorialActivity.class);
        startActivity(intent);
    }
}