package com.example.assignmenttest.recipe;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.assignmenttest.R;
import com.google.gson.Gson;
import com.squareup.picasso.Picasso;
import java.util.List;

public class RecipeAdapter extends RecyclerView.Adapter<RecipeAdapter.RecipeViewHolder> {
    private RecipeActivity mRecipeActivity;
    private List<Recipe> mRecipes;
    public static final String TAG = "RecipeAdapter";
    private boolean mTwoPane;


    public RecipeAdapter(RecipeActivity parent, List<Recipe> recipes, Boolean twoPane) {
        mRecipeActivity = parent;
        mRecipes = recipes;
        mTwoPane = twoPane;
    }

    public static class RecipeViewHolder extends RecyclerView.ViewHolder{
        public TextView title, servings, summary;
        public ImageView rImage;

        public RecipeViewHolder(View v) {
            super(v);
            title = v.findViewById(R.id.tvTitle);
            servings = v.findViewById(R.id.tvServings);
            summary = v.findViewById(R.id.tvSummary);
            rImage = v.findViewById(R.id.ivArt);
        }
    }
    @Override
    public RecipeAdapter.RecipeViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recipe_list_row, parent, false);
        return new RecipeViewHolder(v);
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(RecipeViewHolder holder, int position) {
        Recipe recipe = mRecipes.get(position);
        holder.title.setText(recipe.getTitle());
        holder.servings.setText("Servings: " + recipe.getServings().toString());
        String imageStr = "https://spoonacular.com/recipeImages/" + recipe.getId() + "-90x90." + recipe.getImageType();
        holder.summary.setText("Cooking Time:" + recipe.getReadyInMinutes().toString() + " mins");
        holder.itemView.setTag(recipe);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mTwoPane) {
                    RecipeDetailFragment fragment =  RecipeDetailFragment.newInstance(recipe);
                    mRecipeActivity.getSupportFragmentManager().beginTransaction().replace(R.id.detailContainer, fragment).commit();
                } else {
                    Intent intent = new Intent(mRecipeActivity, RecipeDetailActivity.class);
                    intent.putExtra(RecipeDetailFragment.ARG_ITEM_ID, recipe.getId());
                    Gson gson = new Gson();
                    String myJson = gson.toJson(recipe);
                    intent.putExtra("myjson", myJson);
                    mRecipeActivity.startActivity(intent);
                }
            }
        });
        Picasso.with(holder.rImage.getContext()).load(Uri.parse(imageStr)).into(holder.rImage);
    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return mRecipes.size();
    }

    public void setRecipes(List<Recipe> recipes) {
        mRecipes.clear();
        mRecipes.addAll(recipes);
        notifyDataSetChanged();
    }
}
