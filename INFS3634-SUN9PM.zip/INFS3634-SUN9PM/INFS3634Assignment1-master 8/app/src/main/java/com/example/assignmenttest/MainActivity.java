package com.example.assignmenttest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.example.assignmenttest.Quiz.QuizStartingScreenActivity;
import com.example.assignmenttest.Tutorial.TutorialActivity;
import com.example.assignmenttest.profile.ProfileActivity;
import com.example.assignmenttest.recipe.RecipeActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;


public class MainActivity extends AppCompatActivity {
    private Button mButton, profileButton, tutorialButton, quizButton;


    public static final String EXTRA_MESSAGE = "BTC";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.nav_view);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.nav_home:
                        System.out.println("Tutorial activity launched from main");
                        launchTutorialActivity();
                        return true;
                    case R.id.nav_recipe:
                        launchRecipeActivity();
                        return true;
                    case R.id.nav_profile:
                        launchProfileActivity();
                        return true;
                    default: return true;
                }
            }
        });

        quizButton = findViewById(R.id.quizButton);



    }

    public void launchRecipeActivity() {
        Intent intent = new Intent(this, RecipeActivity.class);
        startActivity(intent);
    }
    public void launchProfileActivity() {
        Intent intent = new Intent(this, ProfileActivity.class);
        startActivity(intent);
    }
    public void launchTutorialActivity() {
        Intent intent = new Intent(this, TutorialActivity.class);
        startActivity(intent);
    }
    public void launchQuiz() {
        Intent intent = new Intent(this, QuizStartingScreenActivity.class);
        startActivity(intent);
    }


    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}