package com.example.assignmenttest.recipe;

import com.example.assignmenttest.mealAPI.Search;
import com.example.assignmenttest.recipe.Meal2;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface RecipeService2 {
    @GET("/recipes/random?number=10&apiKey=5414018ec3cb47dc8d0ba86bb5a697cc")
    Call<Meal2> getRecipes();

    @GET("/recipes/random")
    Call<Meal2> getRecipes(@Query("number") int no, @Query("tags") String tag, @Query("apiKey") String key);
}
