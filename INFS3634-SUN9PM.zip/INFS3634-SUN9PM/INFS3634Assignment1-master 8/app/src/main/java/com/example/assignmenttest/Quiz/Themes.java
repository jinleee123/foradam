package com.example.assignmenttest.Quiz;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class Themes implements Serializable {

    // Generated Java Objects from JSON using http://www.jsonschema2pojo.org/

    @SerializedName("themes")
    @Expose
    private List<Theme> themes;

    public List<Theme> getThemes() {
        return themes;
    }

    public void setThemes(List<Theme> categories) {
        this.themes = themes;
    }

    public static class Theme implements Serializable{

        @SerializedName("idTheme")
        @Expose
        private String idTheme;
        @SerializedName("strTheme")
        @Expose
        private String strTheme;
        @SerializedName("strThemeThumb")
        @Expose
        private String strThemeThumb;
        @SerializedName("strThemeDescription")
        @Expose
        private String strThemeDescription;

        public String getIdTheme() {
            return idTheme;
        }

        public void setIdTheme(String idTheme) {
            this.idTheme = idTheme;
        }

        public String getStrTheme() {
            return strTheme;
        }

        public void setStrTheme(String strTheme) {
            this.strTheme = strTheme;
        }

        public String getStrThemeThumb() {
            return strThemeThumb;
        }

        public void setStrThemeThumb(String strThemeThumb) {
            this.strThemeThumb = strThemeThumb;
        }

        public String getStrThemeDescription() {
            return strThemeDescription;
        }

        public void setStrThemeDescription(String strThemeDescription) {
            this.strThemeDescription = strThemeDescription;
        }

    }
}
