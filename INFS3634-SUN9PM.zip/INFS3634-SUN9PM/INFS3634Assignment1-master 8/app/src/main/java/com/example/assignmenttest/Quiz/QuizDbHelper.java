package com.example.assignmenttest.Quiz;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.assignmenttest.Quiz.QuizContract.*;

import java.util.ArrayList;
import java.util.List;

public class QuizDbHelper extends SQLiteOpenHelper {

    //Quiz Db class was adapted for our application from https://www.youtube.com/watch?v=rEaCu8itHtU&list=PLrnPJCHvNZuDCyg4Usq2gHMzz6_CiyQO7&index=3
    //Categories and questions were based of this video - https://www.youtube.com/watch?v=mONNvMIaulY&list=PLrnPJCHvNZuDCyg4Usq2gHMzz6_CiyQO7&index=14

    private static final String DATABASE_NAME = "MyAwesomeQuiz.db";
    private static final int DATABASE_VERSION = 1;

    private static QuizDbHelper instance;

    private SQLiteDatabase db;

    private QuizDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static synchronized QuizDbHelper getInstance(Context context) {
        if (instance == null) {
            instance = new QuizDbHelper(context.getApplicationContext());
        }
        return instance;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        this.db = db;

        final String SQL_CREATE_THEMES_TABLE = "CREATE TABLE " +
                QuizContract.ThemesTable.TABLE_NAME + "( " +
                QuizContract.ThemesTable._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                QuizContract.ThemesTable.COLUMN_NAME + " TEXT " +
                ")";

        final String SQL_CREATE_QUESTIONS_TABLE = "CREATE TABLE " +
                QuizContract.QuestionsTable.TABLE_NAME + " ( " +
                QuizContract.QuestionsTable._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                QuizContract.QuestionsTable.COLUMN_QUESTION + " TEXT, " +
                QuizContract.QuestionsTable.COLUMN_OPTION1 + " TEXT, " +
                QuizContract.QuestionsTable.COLUMN_OPTION2 + " TEXT, " +
                QuizContract.QuestionsTable.COLUMN_OPTION3 + " TEXT, " +
                QuizContract.QuestionsTable.COLUMN_OPTION4 + " TEXT, " +
                QuizContract.QuestionsTable.COLUMN_ANSWER_NR + " INTEGER, " +
                QuizContract.QuestionsTable.COLUMN_THEME_ID + " INTEGER, " +
                "FOREIGN KEY(" + QuizContract.QuestionsTable.COLUMN_THEME_ID + ") REFERENCES " +
                QuizContract.ThemesTable.TABLE_NAME + "(" + QuizContract.ThemesTable._ID + ")" + "ON DELETE CASCADE" +
                ")";

        db.execSQL(SQL_CREATE_THEMES_TABLE);
        db.execSQL(SQL_CREATE_QUESTIONS_TABLE);
        fillThemesTable();
        fillQuestionsTable();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + QuizContract.ThemesTable.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + QuizContract.QuestionsTable.TABLE_NAME);
        onCreate(db);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    private void fillThemesTable() {
        QuizTheme t1 = new QuizTheme("General");
        insertTheme(t1);
        QuizTheme t2 = new QuizTheme("Salad");
        insertTheme(t2);
        QuizTheme t3 = new QuizTheme("Omelette");
        insertTheme(t3);
        QuizTheme t4 = new QuizTheme("Pasta");
        insertTheme(t4);
        QuizTheme t5 = new QuizTheme("Soup");
        insertTheme(t5);

    }

    public void addTheme(QuizTheme theme) {
        db = getWritableDatabase();
        insertTheme(theme);
    }

    public void addThemes(List<QuizTheme> themes) {
        db = getWritableDatabase();

        for (QuizTheme theme : themes) {
            insertTheme(theme);
        }
    }

    private void insertTheme(QuizTheme theme) {
        ContentValues cv = new ContentValues();
        cv.put(ThemesTable.COLUMN_NAME, theme.getName());
        db.insert(ThemesTable.TABLE_NAME, null, cv);
    }

    private void fillQuestionsTable() {
        Question q1 = new Question("What is the main ingredient in hummus?",
                "Butter beans", "Chickpeas", "Borlotti beans", "Navy bean", 2,
                QuizTheme.General);
        insertQuestion(q1);
        Question q2 = new Question("What is the main ingredient in baba ganoush?",
                "Chickpeas", "Courgette", "Eggplant", "Starch", 3,
                QuizTheme.General);
        insertQuestion(q2);
        Question q3 = new Question("What is the main ingredient in falafel?",
                "Lentils", "Couscous", "Chickpeas", "Potatos", 3,
                QuizTheme.General);
        insertQuestion(q3);
        Question q4 = new Question("Which veggie provides the most protein per calorie?",
                "Broccoli", "Kale", "Mushrooms", "Lima beans", 3,
                QuizTheme.Salad);
        insertQuestion(q4);
        Question q5 = new Question("Which of these make the best  salad base?",
                "Kale", "Iceberg Lettuce", "Rocket", "All of the above", 4,
                QuizTheme.Salad);
        insertQuestion(q5);
        Question q6 = new Question("Whats the best tool to ensure the middle of your steak is cooked?",
                "Sharp eyes", "Add water", "Poke it", "Thermometer", 4,
                QuizTheme.General);
        insertQuestion(q6);
        Question q7 = new Question("Which one of these is a popular vegetarian protein addition to salad?",
                "Halloumi", "Watermelon", "Beef", "Lemon juice", 1,
                QuizTheme.Salad);
        insertQuestion(q7);
        Question q8 = new Question("Which of these is statements are correct when mixing cake batter?",
                "'Make sure its completely mixed'", "'Don't over-mix your batter'", "'Using hands is actually more effective'", "'Eggs always make it worse'", 2,
                QuizTheme.General);
        insertQuestion(q8);
        Question q9 = new Question("What exactly does it mean to 'bake' food",
                "Use oil", "To cook by dry heat", "Tenderise with hammer", "Heat in water", 3,
                QuizTheme.General);
        insertQuestion(q9);
        Question q10 = new Question("How many teaspoons in a tablespoon?",
                "2", "3", "4", "5", 2,
                QuizTheme.General);
        insertQuestion(q10);
        Question q11 = new Question("What temperature is ideal for the perfect omelet?",
                "High", "High-medium", "Medium-low", "Low", 2,
                QuizTheme.Omelette);
        insertQuestion(q11);
        Question q12 = new Question("What does it mean to 'toss' a salad",
                "Throw it out the window", "Cook with water", "Chop vegetables", "Mix with dressing", 4,
                QuizTheme.Salad);
        insertQuestion(q12);
        Question q13 = new Question("Whats a popular fruit addition to salad?",
                "Mango", "Cucumber", "Peach", "Hashbrown", 1,
                QuizTheme.Salad);
        insertQuestion(q13);
        Question q15 = new Question("How can you fix a soup after adding too much salt?",
                "Pouring out some broth", "Adding green vegetables", "Adding pepper", "Adding potatoes or pasta", 4,
                QuizTheme.Soup);
        insertQuestion(q15);
        Question q16 = new Question("What size pan is ideal for cooking an omelette",
                "A 3-quart saucier", "A 9-inch pan", "A 12-inch skillet", "Dutch Oven", 2,
                QuizTheme.Omelette);
        insertQuestion(q16);
        Question q17 = new Question("How do you poach an egg?",
                "Break and gently drop it into hot water", "Stir it into a pan with butter", "Remove the shell and microwave", "Illegally hunt the egg", 1,
                QuizTheme.Omelette);
        insertQuestion(q17);
        Question q18 = new Question("How do you caramelise onions?",
                "Cook it with brown sugar", "Boil in red wine", "Simmer in butter/oil", "Bake it before frying", 3,
                QuizTheme.Omelette);
        insertQuestion(q18);
        Question q19 = new Question("When should pasta be removed from boiling water?",
                "After 10min", "When half the water evaporates", "While its still a little firm", "When its really soft", 3,
                QuizTheme.Pasta);
        insertQuestion(q19);
        Question q20 = new Question("What temperature does water boil?",
                "100 C", "250 C", "50 C", "500 C", 1,
                QuizTheme.Pasta);
        insertQuestion(q20);
        Question q21 = new Question("What is the term used to describe pasta that is “firm to the bite?”",
                "Squishy", "Al Dente", "Fin Firm", "La Stronga", 2,
                QuizTheme.Pasta);
        insertQuestion(q21);
        Question q22 = new Question("In baking recipes, what is usually the first step?",
                "Preheat the oven", "Crack eggs", "Measure everything into bowls", "Put everything in the counter", 1,
                QuizTheme.General);
        insertQuestion(q22);
        Question q23 = new Question("How long does a perfect hardboiled egg take?",
                "7-10min", "10-20min", "1-2min", "3-5min", 1,
                QuizTheme.Omelette);
        insertQuestion(q23);
        Question q24 = new Question("What are the two most common items placed in water to make it “refreshing?”",
                "Apple and avocado slices", "Potato and radish slices", "Lemon and cucumber slices", "Banana and pear slices", 3,
                QuizTheme.General);
        insertQuestion(q24);
        Question q25 = new Question("Which color of veggies should we eat the most of?",
                "Yellows and oranges", "Greens", "A mix of colors", "Bright reds", 3,
                QuizTheme.Salad);
        insertQuestion(q25);
        Question q26 = new Question("Which veggie is considered as a meat 'fill-in' to many?",
                "Jackfruit", "Mushrooms", "A mix of colors", "Both Option 1 and 2", 4,
                QuizTheme.Salad);
        insertQuestion(q26);
        Question q27 = new Question("Which color of veggies should we eat the most of?",
                "Yellows and oranges", "Greens", "A mix of colors", "Bright reds", 3,
                QuizTheme.Salad);
        insertQuestion(q27);
        Question q28 = new Question("Which of the following is a popular lebanese salad?",
                "Fattoush", "Pizza salad", "Sauerkraut", "Coleslaw", 1,
                QuizTheme.Salad);
        insertQuestion(q28);
        Question q29 = new Question("How many times should you flip your omelette?",
                "0-1", "2", "3", "4", 1,
                QuizTheme.Omelette);
        insertQuestion(q29);
        Question q30 = new Question("How long should beef be defrosted for?",
                "15min", "30min", "60min", "0min", 2,
                QuizTheme.General);
        insertQuestion(q30);
        Question q31 = new Question("You're cooking chicken. How hot should the centre be?",
                "63C", "75C", "85C", "100C", 2,
                QuizTheme.Soup);
        insertQuestion(q31);
        Question q32 = new Question("You found last year's lamb chops in the freezer. Can you eat it?",
                "No – clean your freezer more often, mate", "Yes, if it's not freezer-burnt", "Yes, but two years is too long", "Yes – but the taste and texture might be off", 4,
                QuizTheme.Soup);
        insertQuestion(q32);
        Question q33 = new Question("Should you wash chicken before cooking it?",
                "Yes - it removes surface bacteria", "Yes - only if there's blood.", "No - it can introduce bacteria into the meat", "No - it spreads germs in your kitchen", 4,
                QuizTheme.Soup);
        insertQuestion(q33);
        Question q34 = new Question("How to preserve a salad?",
                "In cold water", "Keeping it completely dry", "In hot water", "Vinegar", 2,
                QuizTheme.Salad);
        insertQuestion(q34);
        Question q35 = new Question("Once you've cooked food, when should you put it into the fridge?",
                "Once its stopped steaming", "As soon as possible", "Once it reaches room temperature", "Anytime after four hours of cooking", 1,
                QuizTheme.General);
        insertQuestion(q35);
        Question q36 = new Question("When it comes to Italian pasta and sauces:",
                "the redder the sauce, the longer the pasta should be", "long pastas are best with cream sauces or olive oil", "It's always good!", "Both Option 1 and 2", 2,
                QuizTheme.Pasta);
        insertQuestion(q36);
        Question q37 = new Question("What should you look for when buying fresh mussels?",
                "mussels with widely opened shells", "mussels that are light-colored", "mussels with closed shells or shells that snap shut when tapped", "Both Option 1 and 2", 3,
                QuizTheme.Soup);
        insertQuestion(q37);
        Question q38 = new Question("What type of sauce is best for long, narrowly shaped pasta?",
                "oil-based sauces (thin and smooth)", "thick sauce that contains chunks of meat", "Both Option 1 and 2 are great.", "None of the above", 1,
                QuizTheme.Pasta);
        insertQuestion(q38);
        Question q39 = new Question("When doubling a recipe which of the following should you NEVER double?",
                "flour", "alcohol", "water", "All the above are fine to double", 2,
                QuizTheme.General);
        insertQuestion(q39);
        Question q40 = new Question("Which of the following is a famous Italian soup?",
                "Pumpkin", "Ramen", "Goulash", "Minestrone", 4,
                QuizTheme.Soup);
        insertQuestion(q40);
        Question q45 = new Question("Once meat begins defrosting, any bacteria present can begin multiplying at ",
                "Room temperature", "30C", "40C", "50C", 1,
                QuizTheme.General);
        insertQuestion(q45);
        Question q48 = new Question("What's the best way to thaw frozen seafood, according to cooks?",
                "in cold water", "in milk", "in corn syrup", "in tomato sauce", 2,
                QuizTheme.Soup);
        insertQuestion(q48);
        Question q49 = new Question("What can you add to your scrambled eggs to make them creamier?",
                "Salt", "Cornstarch", "Chives", "Dairy", 4,
                QuizTheme.General);
        insertQuestion(q49);
        Question q50 = new Question("Most rice requires _______ as much water to cook correctly",
                "Half", "Twice", "Three time", "Just as much (1:1)", 2,
                QuizTheme.General);
        insertQuestion(q50);
        Question q51 = new Question("When cutting vegetables and raw meats, what should you do?",
                "Wash the meat with soap first", "Use separate cutting boards", "Defrost vegetables after cutting meat", "Vacuum seal the meat", 2,
                QuizTheme.Salad);
        insertQuestion(q51);
        Question q53 = new Question("Nuts are a good source of: ",
                "Protein", "Fat", "Vitamins", "All of the above", 4,
                QuizTheme.General);
        insertQuestion(q53);
        Question q54 = new Question("When cooking pasta, you should add a pinch of ______ to the water ",
                "Oil", "Vinegar", "Paprika", "Salt", 4,
                QuizTheme.Pasta);
        insertQuestion(q54);
        Question q56 = new Question("Beat cream long enough, and it will turn into",
                "Yoghurt", "Sour Cream", "Whipped Cream", "Cheese", 3,
                QuizTheme.General);
        insertQuestion(q56);
        Question q57 = new Question("Pasta Bolognese is best paired with what kind of wine?",
                "Rosé", "White", "Dessert Wine", "Red", 4,
                QuizTheme.Pasta);
        insertQuestion(q57);
        Question q58 = new Question("What sauce goes well with omelette",
                "Barbecue", "Hot sauce", "Plum sauce", "1 and 2", 4,
                QuizTheme.Omelette);
        insertQuestion(q58);

        Question q62 = new Question("What type of food is a slow cooker best used for?",
                "Steak", "Stews", "Pizza", "Fries", 2,
                QuizTheme.General);
        insertQuestion(q62);
        Question q63 = new Question("Nuts are a good source of: ",
                "Protein", "Fat", "Vitamins", "All of the above", 4,
                QuizTheme.Salad);
        insertQuestion(q63);
        Question q64 = new Question("Salad is best paired with what kind of wine?",
                "Rosé", "White", "Dessert Wine", "Red", 2,
                QuizTheme.Salad);
        insertQuestion(q64);

    }

    public void addQuestion(Question question) {
        db = getWritableDatabase();
        insertQuestion(question);
    }

    public void addQuestions(List<Question> questions) {
        db = getWritableDatabase();

        for (Question question : questions) {
            insertQuestion(question);
        }
    }

    private void insertQuestion(Question question) {
        ContentValues cv = new ContentValues();
        cv.put(QuestionsTable.COLUMN_QUESTION, question.getQuestion());
        cv.put(QuestionsTable.COLUMN_OPTION1, question.getOption1());
        cv.put(QuestionsTable.COLUMN_OPTION2, question.getOption2());
        cv.put(QuestionsTable.COLUMN_OPTION3, question.getOption3());
        cv.put(QuestionsTable.COLUMN_OPTION4, question.getOption4());
        cv.put(QuestionsTable.COLUMN_ANSWER_NR, question.getAnswerNr());
        cv.put(QuestionsTable.COLUMN_THEME_ID, question.getThemeID());
        db.insert(QuestionsTable.TABLE_NAME, null, cv);
    }

    public List<QuizTheme> getAllCategories() {
        List<QuizTheme> themeList = new ArrayList<>();
        db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + ThemesTable.TABLE_NAME, null);

        if (c.moveToFirst()) {
            do {
                QuizTheme theme = new QuizTheme();
                theme.setId(c.getInt(c.getColumnIndex(ThemesTable._ID)));
                theme.setName(c.getString(c.getColumnIndex(ThemesTable.COLUMN_NAME)));
                themeList.add(theme);
            } while (c.moveToNext());
        }

        c.close();
        return themeList;
    }

    public ArrayList<Question> getAllQuestions() {
        ArrayList<Question> questionList = new ArrayList<>();
        db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + QuizContract.QuestionsTable.TABLE_NAME, null);

        if (c.moveToFirst()) {
            do {
                Question question = new Question();
                question.setId(c.getInt(c.getColumnIndex(QuestionsTable._ID)));
                question.setQuestion(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_QUESTION)));
                question.setOption1(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION1)));
                question.setOption2(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION2)));
                question.setOption3(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION3)));
                question.setOption4(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION4)));
                question.setAnswerNr(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_ANSWER_NR)));
                question.setThemeID(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_THEME_ID)));
                questionList.add(question);
            } while (c.moveToNext());
        }

        c.close();
        return questionList;
    }

    public ArrayList<Question> getQuestions(int categoryID) {
        ArrayList<Question> questionList = new ArrayList<>();
        db = getReadableDatabase();

        String selection = QuestionsTable.COLUMN_THEME_ID + " = ? ";
        String[] selectionArgs = new String[]{String.valueOf(categoryID)};

        Cursor c = db.query(
                QuestionsTable.TABLE_NAME,
                null,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        if (c.moveToFirst()) {
            do {
                Question question = new Question();
                question.setId(c.getInt(c.getColumnIndex(QuestionsTable._ID)));
                question.setQuestion(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_QUESTION)));
                question.setOption1(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION1)));
                question.setOption2(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION2)));
                question.setOption3(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION3)));
                question.setOption4(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION4)));
                question.setAnswerNr(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_ANSWER_NR)));
                question.setThemeID(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_THEME_ID)));
                questionList.add(question);
            } while (c.moveToNext());
        }

        c.close();
        return questionList;
    }
}
