package com.example.assignmenttest.Tutorial;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.assignmenttest.R;
import com.example.assignmenttest.recipe.Recipe;
import com.example.assignmenttest.recipe.RecipeActivity;
import com.example.assignmenttest.recipe.RecipeAdapter;
import com.example.assignmenttest.recipe.RecipeDetailActivity;
import com.example.assignmenttest.recipe.RecipeDetailFragment;
import com.google.gson.Gson;
import com.squareup.picasso.Picasso;

import java.util.List;

public class LevelAdapter extends RecyclerView.Adapter<com.example.assignmenttest.recipe.RecipeAdapter.RecipeViewHolder> {
    private com.example.assignmenttest.Tutorial.TutorialDetailActivity mTutorialDetailActivity;
    private List<Recipe> mRecipes;
    public static final String TAG = "LevelAdapter";
    private boolean mTwoPane;


    public LevelAdapter(TutorialDetailActivity parent, List<Recipe> recipes, Boolean twoPane) {
        mTutorialDetailActivity = parent;
        mRecipes = recipes;
        mTwoPane = twoPane;
    }

    public static class RecipeViewHolder extends RecyclerView.ViewHolder{
        public TextView title, servings, summary;
        public ImageView rImage;

        public RecipeViewHolder(View v) {
            super(v);
            title = v.findViewById(R.id.tvTitle);
            servings = v.findViewById(R.id.tvServings);
            summary = v.findViewById(R.id.tvSummary);
            rImage = v.findViewById(R.id.ivArt);
        }
    }
    @Override
    public RecipeAdapter.RecipeViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recipe_list_row, parent, false);
        return new RecipeAdapter.RecipeViewHolder(v);
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(RecipeAdapter.RecipeViewHolder holder, int position) {
        Recipe recipe = mRecipes.get(position);
        holder.title.setText(recipe.getTitle());
        holder.servings.setText("Servings" + recipe.getServings().toString());
        String imageStr = "https://spoonacular.com/recipeImages/" + recipe.getId() + "-90x90." + recipe.getImageType();
        holder.summary.setText("Cooking Time:" + recipe.getReadyInMinutes().toString() + " mins");
        holder.itemView.setTag(recipe);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mTwoPane) {
                    RecipeDetailFragment fragment =  RecipeDetailFragment.newInstance(recipe);
                    mTutorialDetailActivity.getSupportFragmentManager().beginTransaction().replace(R.id.detailContainer, fragment).commit();
                } else {
                    Intent intent = new Intent(mTutorialDetailActivity, RecipeDetailActivity.class);
                    intent.putExtra(RecipeDetailFragment.ARG_ITEM_ID, recipe.getId());
                    Gson gson = new Gson();
                    String myJson = gson.toJson(recipe);
                    intent.putExtra("myjson", myJson);
                    mTutorialDetailActivity.startActivity(intent);
                }
            }
        });
        Picasso.with(holder.rImage.getContext()).load(Uri.parse(imageStr)).into(holder.rImage);
    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return mRecipes.size();
    }

    public void setRecipes(List<Recipe> recipes) {
        mRecipes.clear();
        mRecipes.addAll(recipes);
        notifyDataSetChanged();
    }
}
