package com.example.assignmenttest.Tutorial;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.assignmenttest.Level;
import com.example.assignmenttest.Quiz.QuizStartingScreenActivity;
import com.example.assignmenttest.R;
import com.example.assignmenttest.profile.ProfileActivity;
import com.example.assignmenttest.recipe.Meal2;
import com.example.assignmenttest.recipe.Recipe;
import com.example.assignmenttest.recipe.RecipeActivity;
import com.example.assignmenttest.recipe.RecipeService2;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.example.assignmenttest.Quiz.QuizStartingScreenActivity.KEY_HIGHSCORE;
import static com.example.assignmenttest.Quiz.QuizStartingScreenActivity.SHARED_PREFS;

public class TutorialActivity extends AppCompatActivity {
    ImageView streakIV, rCompletedIV;
    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    private TutorialAdapter tAdapter;
    public static final String TAG = "TutorialActivity";
    protected ArrayList<Level> levels = Level.getLevel();
    private Button quizButton;
    public static final String SHARED_PREFS = "sharedPrefs";
    public static final String KEY_HIGHSCORE = "keyHighscore";
    TextView highScoreTV, xpTv, levelTV;
    private int highscore, xp;
    private String xpString, level;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutorial);

        quizButton = findViewById(R.id.quizButton);
        quizButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchQuiz();
            }
        });
        highScoreTV = findViewById(R.id.hsTV);
        loadHighscore();
        System.out.println("loaded high score");
        xpTv = findViewById(R.id.xpTV);
        xp = ProfileActivity.retrieveXP();
        System.out.println("retieved xp");
        xpString=xp+"xp";
        System.out.println(xpString);
        xpTv.setText(xpString);

        levelTV = findViewById(R.id.levelTV);
        level = ProfileActivity.getLevel();
        System.out.println("retrieved level");
        System.out.println(level);
        levelTV.setText("Level: " + level);

        mRecyclerView = findViewById(R.id.tutorialList);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);
        tAdapter = new TutorialAdapter(this, new ArrayList<Level>());
        mRecyclerView.setAdapter(tAdapter);
        tAdapter.setLevels(levels);
        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.nav_view);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.nav_home:
                        launchTutorialActivity();
                        return true;
                    case R.id.nav_recipe:
                        launchRecipeActivity();
                        return true;
                    case R.id.nav_profile:
                        launchProfileActivity();
                        return true;
                    default: return true;
                }
            }
        });
    }

    void getResults(ArrayList<Level> levels) {
        System.out.println("reached get results");
        Retrofit retrofit = new Retrofit.Builder().baseUrl("https://api.spoonacular.com").addConverterFactory(GsonConverterFactory.create()).build();
        //System.out.println("Created retrofit");
        RecipeService2 service = retrofit.create(RecipeService2.class);
        for (Level level : levels) {
            String theme = level.getTheme();
            Call<Meal2> resultCall = service.getRecipes(6,theme, "4127a24758274b4599f3d111ca094cbf");
            System.out.println("Created call");
            resultCall.enqueue(new Callback<Meal2>() {
                @Override
                public void onResponse(@NonNull Call<Meal2> call, @NonNull Response<Meal2> response) {
                    System.out.println("reached on response");

                    if (response.isSuccessful() && response.body() != null) {
                        List<Recipe> recipes = response.body().getRecipes();
                        level.setRecipeList(recipes);
                        for (Recipe recipe : level.getRecipeList()) {
                            System.out.println(recipe.getTitle());
                        }

                    } else

                    {
                        System.out.println(response.message());
                    }
                }

                @Override
                public void onFailure (@NonNull Call < Meal2 > call, @NonNull Throwable t){
                    System.out.println("response not successful");
                    System.out.println(t.getLocalizedMessage());
                }
            });
        }
    }
    private void launchQuiz() {
        Intent intent = new Intent(this, QuizStartingScreenActivity.class);
        intent.putExtra("ThemeID", 1);
        intent.putExtra("ThemeName", "General");
        startActivity(intent);
    }
    public void launchRecipeActivity() {
        Intent intent = new Intent(this, RecipeActivity.class);
        startActivity(intent);
    }
    public void launchProfileActivity() {
        Intent intent = new Intent(this, ProfileActivity.class);
        startActivity(intent);
    }
    public void launchTutorialActivity() {
        Intent intent = new Intent(this, TutorialActivity.class);
        startActivity(intent);
    }
    private void loadHighscore() {
        SharedPreferences prefs = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        highscore = prefs.getInt(KEY_HIGHSCORE, 0);
        highScoreTV.setText(getResources().getString(R.string.high_score) + highscore);
    }



}