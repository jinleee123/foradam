package com.example.assignmenttest.recipe;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Meal2 {

    @SerializedName("recipes")
    @Expose
    private List<Recipe> recipes = null;

    /**
     * No args constructor for use in serialization
     *
     */
    public Meal2() {
    }

    /**
     *
     * @param recipes
     */
    public Meal2(List<Recipe> recipes) {
        super();
        this.recipes = recipes;
    }

    public List<Recipe> getRecipes() {
        return recipes;
    }

    public void setRecipes(List<Recipe> recipes) {
        this.recipes = recipes;
    }

}
