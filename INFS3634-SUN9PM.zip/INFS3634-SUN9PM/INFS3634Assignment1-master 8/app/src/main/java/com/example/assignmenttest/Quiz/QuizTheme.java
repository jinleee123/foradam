package com.example.assignmenttest.Quiz;

public class QuizTheme {

    //QuizCategory class was established based on https://www.youtube.com/watch?v=VuR1xOnaD0E&list=PLrnPJCHvNZuDCyg4Usq2gHMzz6_CiyQO7&index=12&t=0s

    public static final int General = 1;
    public static final int Salad = 2;
    public static final int Omelette = 3;
    public static final int Pasta = 4;
    public static final int Soup = 5;


    private int id;
    private String name;

    public QuizTheme() {
    }

    public QuizTheme(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return getName();
    }
}
