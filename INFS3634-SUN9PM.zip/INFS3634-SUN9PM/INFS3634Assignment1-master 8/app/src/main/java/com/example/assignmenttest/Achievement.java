package com.example.assignmenttest;

import java.util.ArrayList;

public class Achievement {
    private String id;
    private String name;
    private String description;

    public String getId(){return id;
    }
    public void setId(String id){this.id= id;}

    public String getName(){return name;
    }
    public void setName(String name){this.name = name;}
    public String getDesciprtion(){return description;
    }
    public void setDesciprtion(String desciprtion){this.description = desciprtion;}

    public Achievement(String id, String name, String description){
        this.id=id;
        this.name=name;
        this.description=description;
    }
    public static ArrayList<Achievement> getAchievement() {
        ArrayList<Achievement> achievements = new ArrayList<>();
        achievements.add(new Achievement("1", "Just starting out", "You have reached 100xp! Keep going superstar!"));
        achievements.add(new Achievement("2", "Sous-chef", "You have reached 200xp! Lets keep going ratatouille"));
        achievements.add(new Achievement("3",  "Masterchef", "You have reached 300xp! Give us YOU on a plate!"));
        achievements.add(new Achievement("4", "Gordon Ramsay", "You have over 400xp! Pressure is healthy but only very few can handle it!"));
        return achievements;
    }

}
