package com.example.assignmenttest.Tutorial;

import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.example.assignmenttest.R;
import com.example.assignmenttest.mealAPI.AnalyzedInstruction;
import com.example.assignmenttest.mealAPI.ExtendedIngredient;
import com.example.assignmenttest.mealAPI.Step;
import com.example.assignmenttest.mealAPI.WinePairing;
import com.example.assignmenttest.recipe.Recipe;
import com.squareup.picasso.Picasso;

import java.util.List;

public class TutorialRecipeDetailFragment extends Fragment {
    public static final String ARG_ITEM_ID = "itemId";
    public static final String TAG = "RecipeDetailFragment";
    private Recipe mRecipe;
    private List<ExtendedIngredient> ingredients;
    private String ingredientList = "";
    private List<AnalyzedInstruction> instructions;
    private String instructionList = "";
    private List<Step> steps;
    private String pairingWines;
    private WinePairing winePairing;
    private ImageView rImage;

    public TutorialRecipeDetailFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_detailrecipe, container, false);
        updateUi(rootView);
        return rootView;
    }

    private void updateUi(View rootView) {
        //View rootView = getView();


        if (mRecipe != null) {
            System.out.println(mRecipe.getTitle());
            System.out.println("successfully passed object through");
            for (ExtendedIngredient ingredient : ingredients) {
                ingredientList = (ingredientList +
                        "• " + ingredient.getName() + System.getProperty("line.separator"));
            }
            System.out.println(ingredientList);
            for (AnalyzedInstruction instruction : instructions) {
                steps = instruction.getSteps();
                System.out.println("new instruction");
                for (Step step : steps) {
                    instructionList = (instructionList + step.getNumber() + ". " + step.getStep() + System.getProperty("line.separator"));
                }
            }
            System.out.println(instructionList);
            System.out.println("instruction list printed");
            System.out.println("Wine pairing: " + winePairing.getPairingText());


            this.rImage = rootView.findViewById(R.id.ivRecipe);
            ((TextView) rootView.findViewById(R.id.tvName)).setText(mRecipe.getTitle());
            ((TextView) rootView.findViewById(R.id.tvHealthscore)).setText(mRecipe.getHealthScore().toString());
            //((TextView) rootView.findViewById(R.id.tvValueField)).setText(formatter.format(Double.valueOf(mCoin.getPriceUsd())));
            //((TextView) rootView.findViewById(R.id.tvChange1hField)).setText(mCoin.getPercentChange1h() + " %");
            //((TextView) rootView.findViewById(R.id.tvChange24hField)).setText(mCoin.getPercentChange24h() + " %");
            //((TextView) rootView.findViewById(R.id.tvChange7dField)).setText(mCoin.getPercentChange7d() + " %");
            //((TextView) rootView.findViewById(R.id.tvMarketcapField)).setText(formatter.format(Double.valueOf(mCoin.getMarketCapUsd())));
            String imageStr = "https://spoonacular.com/recipeImages/" + mRecipe.getId() + "-90x90." + mRecipe.getImageType();
            Picasso.with(rImage.getContext()).load(Uri.parse(imageStr)).into(rImage);
        }
    }

    protected void setObject(Recipe recipe) {
        this.mRecipe = recipe;
        this.ingredients = recipe.getExtendedIngredients();
        this.instructions = recipe.getAnalyzedInstructions();
        this.winePairing = recipe.getWinePairing();
    }


}
