package com.example.assignmenttest.Tutorial;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.assignmenttest.Level;
import com.example.assignmenttest.Quiz.QuizStartingScreenActivity;
import com.example.assignmenttest.R;
import com.example.assignmenttest.recipe.Meal2;
import com.example.assignmenttest.recipe.Recipe;
import com.example.assignmenttest.recipe.RecipeService2;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class TutorialDetailActivity extends AppCompatActivity implements Serializable {

    public static final String EXTRA_MESSAGE = "au.edu.unsw.infs3634.beers.MESSAGE";
    private static Retrofit retrofit = null;
    public static final String TAG = "RecipeActivity";
    private LevelAdapter mAdapter;
    private boolean mTwoPane;
    public Level tdLevel;
    public List<Recipe> mRecipes;
    RecyclerView mRecyclerView;
    protected ArrayList<Level> levels = Level.getLevel();
    private Button quizButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutorial_detail);
        if (findViewById(R.id.detailContainer) != null) {
            mTwoPane = true;
        }
        quizButton = findViewById(R.id.quizButton);

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int height = dm.heightPixels;

        mRecyclerView = findViewById(R.id.rvList);
        ViewGroup.LayoutParams params=mRecyclerView.getLayoutParams();
        params.height =(int)(height*0.8);
        mRecyclerView.setLayoutParams(params);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(mLayoutManager);

        tdLevel = levels.get(getIntent().getIntExtra("Level", 0));
        //new GetRecipeTask().execute();
        getResults(tdLevel);
        System.out.println(tdLevel.getTheme());
        mAdapter = new LevelAdapter(this, new ArrayList<Recipe>(), mTwoPane);

        mRecyclerView.setAdapter(mAdapter);
        quizButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchQuiz(tdLevel);
            }
        });


    }
    void getResults(Level level) {
        System.out.println("reached get results");
        Retrofit retrofit = new Retrofit.Builder().baseUrl("https://api.spoonacular.com").addConverterFactory(GsonConverterFactory.create()).build();
        //System.out.println("Created retrofit");
        RecipeService2 service = retrofit.create(RecipeService2.class);
        String theme = level.getTheme().toLowerCase();
        Call<Meal2> resultCall = service.getRecipes(6, theme, "5414018ec3cb47dc8d0ba86bb5a697cc");
        System.out.println("Created call");
        resultCall.enqueue(new Callback<Meal2>() {
            @Override
            public void onResponse(@NonNull Call<Meal2> call, @NonNull Response<Meal2> response) {
                System.out.println("reached on response");
                System.out.println(theme);

                if (response.isSuccessful() && response.body() != null) {
                    List<Recipe> recipes = response.body().getRecipes();
                    level.setRecipeList(recipes);
                    mAdapter.setRecipes(level.getRecipeList());
                    for (Recipe recipe : level.getRecipeList()) {
                        System.out.println(recipe.getTitle());
                    }

                } else {
                    System.out.println(response.message());
                }
            }

            @Override
            public void onFailure(@NonNull Call<Meal2> call, @NonNull Throwable t) {
                System.out.println("response not successful");
                System.out.println(t.getLocalizedMessage());
            }
        });
    }

    private class GetRecipeTask extends AsyncTask<Void, Void, List<Recipe>> {
        @Override
        protected List<Recipe> doInBackground(Void... voids) {
            try {
                Log.d(TAG, "doInBackground: SUCCESS");
                Retrofit retrofit = new Retrofit.Builder().baseUrl("https://api.spoonacular.com").addConverterFactory(GsonConverterFactory.create()).build();
                //System.out.println("Created retrofit");
                RecipeService2 service = retrofit.create(RecipeService2.class);
                String theme = tdLevel.getTheme();
                Call<Meal2> resultCall = service.getRecipes(6, theme, "5414018ec3cb47dc8d0ba86bb5a697cc");

                Response<Meal2> recipeResponse = resultCall.execute();
                List<Recipe> recipes = recipeResponse.body().getRecipes();
                for (Recipe recipe: recipes){
                    System.out.println(recipe.getTitle());
                }

                return recipes;

            } catch (IOException e){
                Log.d(TAG, "onFailure: FAILURE");
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(List<Recipe> recipes) {
            //super.onPostExecute(coins);
            System.out.println("recipes set");
            mAdapter.setRecipes(recipes);
        }
    }
    private void launchQuiz(Level level) {
        Intent intent = new Intent(this, QuizStartingScreenActivity.class);
        switch(level.getTheme()){
            case("Salad"):
                intent.putExtra("ThemeID", 2);
                intent.putExtra("ThemeName", "Salad");
                break;
            case("Omelette"):
                intent.putExtra("ThemeID", 3);
                intent.putExtra("ThemeName", "Omelette");
                break;
            case("Pasta"):
                intent.putExtra("ThemeID", 4);
                intent.putExtra("ThemeName", "Pasta");
                break;
            case("Soup"):
                intent.putExtra("ThemeID", 5);
                intent.putExtra("ThemeName", "Soup");
                break;

            }
        startActivity(intent);
    }
}
